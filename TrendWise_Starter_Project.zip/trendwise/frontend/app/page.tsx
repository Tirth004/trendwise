
export default function HomePage() {
  return <div className="p-4">Welcome to TrendWise Blog!</div>
}
